import { PageHeader } from "antd";

function Title() {
    return (
      <PageHeader className="site-page-header" title="농산물 직거래 플랫폼" />
    );
  }

  export default Title