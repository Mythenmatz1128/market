import { AutoComplete, Col, Divider, Row } from 'antd';
import React from 'react';
import pic from "../img/샤인머스켓.png"
const style = {
  padding: '8px 0',
};
const imgStyle ={
  width:'200px',
  height:'220px'
}

const Grid = () => (
  <>
    
    <Divider orientation="left"></Divider>
    <Row gutter={[16, 24]}>
      <Col className="gutter-row" span={6}>
        <div className='main-flex-item' style={style}><img style={imgStyle} src={pic}/> 제목: 샤인머스켓
        가격:20000</div>
      </Col>
      <Col className="gutter-row" span={6}>
        <div className='main-flex-item' style={style}><img style={imgStyle} src={pic}/></div>
      </Col>
      <Col className="gutter-row" span={6}>
        <div className='main-flex-item' style={style}><img style={imgStyle} src={pic}/></div>
      </Col>
      <Col className="gutter-row" span={6}>
        <div className='main-flex-item' style={style}><img style={imgStyle} src={pic}/></div>
      </Col>
      <Col className="gutter-row" span={6}>
        <div className='main-flex-item' style={style}><img style={imgStyle} src={pic}/></div>
      </Col>
      <Col className="gutter-row" span={6}>
        <div className='main-flex-item' style={style}><img style={imgStyle} src={pic}/></div>
      </Col>
      <Col className="gutter-row" span={6}>
        <div className='main-flex-item' style={style}><img style={imgStyle} src={pic}/></div>
      </Col>
      <Col className="gutter-row" span={6}>
        <div className='main-flex-item' style={style}><img style={imgStyle} src={pic}/></div>
      </Col>
    </Row>
  </>
);

export default Grid;