import pic from "../img/샤인머스켓.png";
import { Carousel } from "antd";
import React, { useState } from "react";
const imgStyle = {
    border: "1px solid green",
    width: "750px",
    height: "300px",
    margin: "auto",
  };
  const contentStyle = {
    height: "300px",
    color: "#fff",
    lineHeight: "300px",
    textAlign: "center",
    background: "#364d79",
    width: "750px",
    margin: "auto",
    marginTop : "10px"
  };
  
function MainCarousel() {
    return (
      <Carousel autoplay>
        <div>
          <h3 style={contentStyle}>
            <img src={pic} style={imgStyle} />
          </h3>
        </div>
        <div>
          <h3 style={contentStyle}>2</h3>
        </div>
        <div>
          <h3 style={contentStyle}>3</h3>
        </div>
        <div>
          <h3 style={contentStyle}>4</h3>
        </div>
      </Carousel>
    );
  }
  
  export default MainCarousel